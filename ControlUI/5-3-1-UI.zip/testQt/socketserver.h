#ifndef SOCKETSERVER_H
#define SOCKETSERVER_H

#include<opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <fcntl.h>

using namespace cv;

#define PACKAGENUM 2
#define IMGWIDTH 640
#define IMGHEIGHT 480
#define BLOCKSIZE IMGWIDTH*IMGHEIGHT*3/PACKAGENUM

struct dataBuf
{
    char buf[BLOCKSIZE];
    int flag;
    int rect[4];
};

class SocketServer
{
public:
    SocketServer(void);
    ~SocketServer(void);
    int socketCtrl;
private:
    struct dataBuf data;
    int needSize;
    int count;

public:

    // socket连接
    int socketConnect(const char* IP, int PORT);
    // 传输图像
    int receive(cv::Mat& image,int& sx,int& sy,int& ex,int& ey);
    // 断开socket连接
    void socketDisconnect(void);
    // 向客户端发送数据
    void sendData(cv::Rect);
    // 收敛鼠标选取范围
    void normalRect(int& value,int bound);


};

#endif // SOCKETSERVER_H
