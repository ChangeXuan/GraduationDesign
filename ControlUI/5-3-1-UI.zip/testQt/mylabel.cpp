#include "mylabel.h"
#include <QPen>
#include<QPainter>

myLabel::myLabel(QWidget *parent): QLabel(parent)
{

}


/*
    绘制函数
    响应条件为update函数被调用
*/
void myLabel::paintEvent(QPaintEvent *event)
{
    // 配置画笔
    QPainter painter(this);
    QPen pen;                                
    pen.setColor(Qt::red);
    pen.setWidth(5);
    painter.setPen(pen);

    // 绘制矩形
    painter.drawRect(startX, startY, endX-startX, endY-startY);
}

/*
    鼠标响应事件
    当鼠标移动时系统调用
*/
void myLabel::mouseMoveEvent(QMouseEvent *e)
{
    // 取得鼠标的点
    endX = e->pos().x();
    endY = e->pos().y();
    update();

}

/*
    鼠标响应事件
    当鼠标按下时系统调用
*/
void myLabel::mousePressEvent(QMouseEvent *event)
{
    startX = event->pos().x();
    startY = event->pos().y();
}

/*
    鼠标响应事件
    当鼠标抬起时系统调用
*/
void myLabel::mouseReleaseEvent(QMouseEvent *event) {
    endX = event->pos().x();
    endY = event->pos().y();
}
