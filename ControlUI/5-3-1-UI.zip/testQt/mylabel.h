#ifndef MYLABEL_H
#define MYLABEL_H
#include <QLabel>
#include <QPoint>
#include <QColor>
#include <QPaintEvent>
#include <QImage>
#include <QPixmap>

class myLabel : public QLabel
{
    //Q_OBJECT  //必须没有，要不然会报错，因为Label不是Widget
public:
    int startX=0;
    int startY=0;
    int endX=0;
    int endY=0;
    myLabel(QWidget *parent=NULL);
    //绘制线条
    void paintEvent(QPaintEvent *event);
    void mouseMoveEvent(QMouseEvent *);
    void mousePressEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
};

#endif

