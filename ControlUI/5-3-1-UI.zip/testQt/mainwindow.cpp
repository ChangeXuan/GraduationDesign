#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "socketserver.h"
#include <QFileDialog>
#include <QPainter>
#include <QTextStream>
#include<QMessageBox>

// 是否正在显示图片流
bool isShow = false;
// 是否按下停止键
bool isStop = true;
// socket服务类
SocketServer server;
// 是否正在进行鼠标旋转
bool isSelect = false;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

/*
    按下show按钮，开启socket连接并获取图片流
*/
void MainWindow::on_pushButton_clicked()
{
    if (!isShow)
    {
        isShow = true;
        isStop = true;

        // 显示lable为等待文字
        ui->label->setText("请等待。。。。。。。");
        // 延时一秒为了保证label文字修改成功
        cv::waitKey(1000);

        // 获取用户填写的端口号
        int portNum = ui->lineEdit->text().toInt();
        // 获取用户填写的客户端地址
        QString arrStr = ui->arrNum->text();
        // 把QString转为byte
        QByteArray arrAry = arrStr.toLatin1();
        // 进行socket连接
        if (server.socketConnect(arrAry.data(), portNum) < 0)
        {
            return ;
        }

        // 循环获取图片数据流
        loopGetData();

    }
}

/*
    循环获取图片函数
*/
void MainWindow::loopGetData()
{
    cv::Mat image;
    // 当没有close和没有进行选取时无限循环
    while (isStop && !isSelect)
    {
        // 取得image和相关动态矩形框参数
        if(server.receive(image,ui->label_2->startX,ui->label_2->startY,ui->label_2->endX,ui->label_2->endY) > 0)
        {
            // UI显示矩形框的坐标信息
            ui->startPoint->setText(tr("start:(%1,%2)").arg(ui->label_2->startX).arg(ui->label_2->startY));
            ui->endPoint->setText(tr("end:(%1,%2)").arg(ui->label_2->endX).arg(ui->label_2->endY));
            //把获取到的Mat类型的图片转成QT支持的QImage格式
            QImage showImage((const uchar*)image.data,image.cols,image.rows,image.cols*image.channels(),QImage::Format_RGB888);
            //将图片显示在QLabel上
            ui->label->setPixmap(QPixmap::fromImage(showImage)); 
            // 更新画布
            ui->label_2->update();

        }
        cv::waitKey(30);
    }
}

/*
    关闭socket连接
*/
void MainWindow::on_pushButton_2_clicked()
{
    if (isShow) {
        // 动态增加端口号，便于再次show
        ui->lineEdit->setText(tr("%1").arg(ui->lineEdit->text().toInt()+1));
        selfCloseSocket();
    }
}

/*
    点击关闭应用程序时的触发函数
*/
void MainWindow::closeEvent(QCloseEvent *event)
{
    switch( QMessageBox::information(this,tr("提示"),tr("你确定退出该软件?"),tr("确定"), tr("取消"),0,1))
    {
    case 0:
        // 点击确定关闭
        if (isShow) {
            selfCloseSocket();
        }
        event->accept();
        break;
    case 1:
    default:
        event->ignore();
        break;
    }
}

/*
    配置socket关闭信息
*/
void MainWindow::selfCloseSocket() {
    server.sendData(cv::Rect(77777,7,7,7));
    server.socketDisconnect();
    isStop = false;
    isShow = false;
}

/*
    点击发送按钮时的回调函数
    发送选取的矩形框数据到ROS
*/
void MainWindow::on_pushButton_3_clicked()
{
    startX = ui->label_2->startX;
    startY = ui->label_2->startY;
    endX = ui->label_2->endX;
    endY = ui->label_2->endY;

    // 使发送的值归一化，避免超出边界
    server.normalRect(startX,460);
    server.normalRect(startY,300);
    server.normalRect(endX,460);
    server.normalRect(endY,300);

    server.sendData(cv::Rect(startX,startY,endX-startX,endY-startY));
    isSelect = false;
    loopGetData();
}

/*
    点击选取按钮时的回调函数
    配置标志位
*/
void MainWindow::on_pushButton_4_clicked()
{
    isSelect = true;
}

/*
    点击run按钮的回调函数
    向ROS发送让机器人运动的控制指令
*/
void MainWindow::on_run_clicked()
{
    if (isShow) {
        server.sendData(cv::Rect(11111,1,1,1));
    }
}

/*
    点击stop按钮的回调函数
    向ROS发送让机器人停止运动的控制指令
*/
void MainWindow::on_stop_clicked()
{
    if (isShow) {
        server.sendData(cv::Rect(00000,1,1,1));
    }
}
