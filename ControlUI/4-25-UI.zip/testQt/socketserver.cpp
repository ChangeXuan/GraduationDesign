#include "socketserver.h"

SocketServer::SocketServer(void)
{
}


SocketServer::~SocketServer(void)
{
}

int SocketServer::socketConnect(int PORT)
{
    int socketFd = socket(AF_INET,SOCK_STREAM, 0);

    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if(bind(socketFd,(struct sockaddr *)&serverAddr,sizeof(serverAddr))==-1)
    {
        perror("bind");
        return -1;
    }

    if(listen(socketFd,5) == -1)
    {
        perror("listen");
        return -1;
    }

    struct sockaddr_in clientAddr;
    socklen_t length = sizeof(clientAddr);

    socketCtrl = accept(socketFd, (struct sockaddr*)&clientAddr, &length);
    if(socketCtrl<0)
    {
        perror("connect");
        return -1;
    }
    else
    {
        printf("connect successful!\n");
        return 1;
    }

    close(socketFd);
}


void SocketServer::socketDisconnect(void)
{
    close(socketCtrl);
}

int SocketServer::receive(cv::Mat& image,int& sx,int& sy,int& ex,int& ey)
{
    int returnflag = 0;
    cv::Mat img(IMGHEIGHT, IMGWIDTH, CV_8UC3, cv::Scalar(0));
    needSize = sizeof(dataBuf);
    count = 0;
    memset(&data,0,sizeof(data));

    for (int i = 0; i < PACKAGENUM; i++)
    {
        int pos = 0;
        int len0 = 0;

        while (pos < needSize)
        {
            len0 = recv(socketCtrl, (char*)(&data) + pos, needSize - pos, 0);
            if (len0 < 0)
            {
                printf("Server Recieve Data Failed!\n");
                break;
            }
            pos += len0;
        }

        sx = data.rect[0],sy = data.rect[1],ex = data.rect[0]+data.rect[2],ey = data.rect[1]+data.rect[3];

        count = count + data.flag;

        int num1 = IMGHEIGHT / PACKAGENUM * i;
        for (int j = 0; j < IMGHEIGHT / PACKAGENUM; j++)
        {
            int num2 = j * IMGWIDTH * 3;
            uchar* ucdata = img.ptr<uchar>(j + num1);
            for (int k = 0; k < IMGWIDTH * 3; k++)
            {
                ucdata[k] = data.buf[num2 + k];
            }
        }


        if (data.flag == 2)
        {
            if (count == PACKAGENUM + 1)
            {
                image = img;
                returnflag = 1;
                count = 0;
            }
            else
            {
                count = 0;
                i = 0;
            }
        }
    }
    if(returnflag == 1)
        return 1;
    else
        return -1;
}


void SocketServer::sendData(cv::Rect roiRect)
{
    if (roiRect.width>0 && roiRect.height>0) {
        int data[] = {roiRect.x,roiRect.y,roiRect.width,roiRect.height};
        send(socketCtrl, (char *)(&data), sizeof(data), 0);
    }

}

void SocketServer::normalRect(int& value,int bound)
{
    if (value > 0)
    {
        value = min(value,bound);
    }
    else
    {
        value = 1;
    }
}
