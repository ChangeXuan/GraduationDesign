#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "socketserver.h"
#include <QFileDialog>
#include <QPainter>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

bool isShow = false;
bool isStop = true;
SocketServer server;

bool isSelect = false;

void MainWindow::on_pushButton_clicked()
{
    if (!isShow) {
        isShow = true;
        isStop = true;

        ui->label->setText("请等待。。。。。。。");

        cv::waitKey(1000);//1s

        if (server.socketConnect(6666) < 0) {
                return;
        }

        loopGetData();

    }
}

void MainWindow::loopGetData() {
    cv::Mat image;
    while (isStop && !isSelect) {
        if(server.receive(image,ui->label_2->startX,ui->label_2->startY,ui->label_2->endX,ui->label_2->endY) > 0) {
            ui->startPoint->setText(tr("start:(%1,%2)").arg(ui->label_2->startX).arg(ui->label_2->startY));
            ui->endPoint->setText(tr("end:(%1,%2)").arg(ui->label_2->endX).arg(ui->label_2->endY));
            cvtColor(image,image,CV_BGR2RGB);
            QImage showImage((const uchar*)image.data,image.cols,image.rows,image.cols*image.channels(),QImage::Format_RGB888);
            ui->label->setPixmap(QPixmap::fromImage(showImage)); //将图片显示在QLabel上
            ui->label_2->update();

        }
        cv::waitKey(30);
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    if (isShow) {
        server.socketDisconnect();
        isStop = false;
        isShow = false;
    }
}

void MainWindow::on_pushButton_3_clicked() {
    startX = ui->label_2->startX;
    startY = ui->label_2->startY;
    endX = ui->label_2->endX;
    endY = ui->label_2->endY;

    server.normalRect(startX,460);
    server.normalRect(startY,300);
    server.normalRect(endX,460);
    server.normalRect(endY,300);

    server.sendData(cv::Rect(startX,startY,endX,endY));
    isSelect = false;
    loopGetData();
}


void MainWindow::on_pushButton_4_clicked() {
    isSelect = true;
}
