#ifndef SOCKETSERVER_H
#define SOCKETSERVER_H

#include<opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <fcntl.h>

using namespace cv;

#define PACKAGE_NUM 2

#define IMG_WIDTH 640
#define IMG_HEIGHT 480

#define BLOCKSIZE IMG_WIDTH*IMG_HEIGHT*3/PACKAGE_NUM

struct recvBuf
{
    char buf[BLOCKSIZE];
    int flag;
    int rect[4];
};

class SocketServer
{
public:
    SocketServer(void);
    ~SocketServer(void);
    int sockConn;
private:
    struct recvBuf data;

    int needRecv;
    int count;

public:

    // 打开socket连接
    // params : PORT    传输端口
    // return : -1      连接失败
    //          1       连接成功
    int socketConnect(int PORT);


    // 传输图像
    // params : image   待接收图像
    //      image   待接收图像
    // return : -1      接收失败
    //          1       接收成功
    int receive(cv::Mat& image,int& sx,int& sy,int& ex,int& ey);


    // 断开socket连接
    void socketDisconnect(void);

    void sendData(cv::Rect);

    void normalRect(int& value,int bound);
};

#endif // SOCKETSERVER_H
