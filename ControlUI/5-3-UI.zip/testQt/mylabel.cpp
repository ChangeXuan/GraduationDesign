#include "mylabel.h"
#include <QPen>
#include<QPainter>

myLabel::myLabel(QWidget *parent): QLabel(parent)
{

}


//绘制线条
void myLabel::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    QPen pen;                                 //创建一个画笔
    pen.setColor(Qt::red);
    pen.setWidth(5);
    painter.setPen(pen);

    painter.drawRect(startX, startY, endX-startX, endY-startY);
}

//in (0,0)~(460,300)
void myLabel::mouseMoveEvent(QMouseEvent *e)
{
    endX = e->pos().x();
    endY = e->pos().y();
    update();

}

void myLabel::mousePressEvent(QMouseEvent *event)
{
    startX = event->pos().x();
    startY = event->pos().y();
}

void myLabel::mouseReleaseEvent(QMouseEvent *event) {
    endX = event->pos().x();
    endY = event->pos().y();
}
