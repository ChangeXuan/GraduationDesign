^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package astra_camera
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.5 (2016-05-27)
------------------
* add dependency on generated messages to avoid race condition at build time
* switching to libusb-1.0
* Contributors: Tully Foote

0.1.4 (2016-05-27)
------------------
* add libusb-dev as a build dependency
* Contributors: Tully Foote

0.1.3 (2016-05-26)
------------------
* Adding build dependency on libudev-dev
* Contributors: Tully Foote

0.1.2 (2016-05-26)
------------------
* add git as a dependency
* Contributors: Tully Foote

0.1.1 (2016-05-26)
------------------
* removing dependency which was internalilzed
* Contributors: Tully Foote

0.1.0 (2016-05-26)
------------------
* Initial release of ROS driver for Astra camera
* Contributors: Ernesto Corbellini, Len Zhong, Tim, Tully Foote, ob-tim-liu
